import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  FileJson, 
  Upload, 
  Printer, 
  Sparkles, 
  Check, 
  AlertTriangle, 
  Info, 
  HelpCircle, 
  RotateCcw, 
  Copy, 
  Maximize2,
  ListFilter
} from 'lucide-react';
import { StartupData, Subfactors, CalculationResult } from './types';
import { 
  INITIAL_STARTUP_DATA, 
  EMPTY_STARTUP_DATA, 
  calculateResult, 
  calculateSubfactors,
  getFactorInterpretations, 
  looksLikeSSIJson, 
  parseSSIJson,
  norm
} from './utils';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [data, setData] = useState<StartupData>(INITIAL_STARTUP_DATA);
  const [activeTab, setActiveTab] = useState<'anketa' | 'expert' | 'result'>('anketa');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Auto-dismiss notification
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Global paste handler to detect any copied startup JSON
  useEffect(() => {
    const handleGlobalPaste = (e: ClipboardEvent) => {
      // Don't intercept if user is active in name/author fields to prevent interrupting typical typing
      const activeElement = document.activeElement;
      if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
        const text = e.clipboardData?.getData('text') || '';
        if (text.trim().startsWith('{') && looksLikeSSIJson(text)) {
          e.preventDefault();
          processJsonString(text);
        }
        return;
      }

      const text = e.clipboardData?.getData('text') || '';
      if (looksLikeSSIJson(text)) {
        e.preventDefault();
        processJsonString(text);
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, []);

  const processJsonString = (text: string) => {
    const parsed = parseSSIJson(text);
    if (parsed) {
      setData(prev => ({ ...prev, ...parsed }));
      showToast('✅ Анкета успешно заполнена из буфера обмена!', 'success');
      setActiveTab('result');
    } else {
      showToast('❌ Ошибка при распознавании JSON анкеты. Проверьте формат.', 'error');
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ message, type });
  };

  const handleInputChange = (key: keyof StartupData, value: string | number) => {
    setData(prev => ({
      ...prev,
      [key]: typeof value === 'number' ? value : value
    }));
  };

  const handleNumberInput = (key: keyof StartupData, valStr: string) => {
    const val = parseFloat(valStr);
    handleInputChange(key, isNaN(val) ? 0 : val);
  };

  const loadPresetDemo = () => {
    setData(INITIAL_STARTUP_DATA);
    showToast('🌱 Загружен демонстрационный проект "Умный Сенсорный Сад"', 'success');
  };

  const resetForm = () => {
    setData(EMPTY_STARTUP_DATA);
    showToast('🧹 Все поля анкеты успешно очищены', 'info');
  };

  const exportToJsonFile = () => {
    try {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = (data.name ? data.name : 'SSI_questionnaire') + '_TRUSEK6.json';
      a.click();
      URL.revokeObjectURL(url);
      showToast('⬇️ Файл анкеты успешно сохранен на ваше устройство', 'success');
    } catch {
      showToast('❌ Не удалось сгенерировать JSON файл', 'error');
    }
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const parsed = parseSSIJson(content);
      if (parsed) {
        setData(prev => ({ ...prev, ...parsed }));
        showToast('✅ Анкета успешно загружена из файла!', 'success');
        setActiveTab('result');
      } else {
        showToast('❌ Ошибка чтения файла. Убедитесь, что это правильный JSON анкеты.', 'error');
      }
    };
    reader.readAsText(file);
    // Reset file input target
    e.target.value = '';
  };

  const handlePasteConsole = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (looksLikeSSIJson(clipText)) {
        processJsonString(clipText);
      } else {
        showToast('📋 В буфере обмена не обнаружен подходящий JSON анкеты. Скопируйте данные заново.', 'info');
      }
    } catch {
      showToast('⚠️ Нет доступа к системному буферу. Просто нажмите Ctrl + V на клавиатуре!', 'info');
    }
  };

  const copyResultsText = (result: CalculationResult) => {
    const info = `
--- РЕЗУЛЬТАТЫ СЕРТИФИКАЦИИ СТАРТАПА SSI ---
Стартап: ${data.name || 'Без названия'}
Автор анкеты: ${data.author || 'Не указан'}
Финальный индекс SSI: ${result.finalSsi.toFixed(2)} / 10
Рыночный мультипликатор MEI: ${result.mei.toFixed(2)}

Оценки по факторам (TRUSEK-6):
- Утилитарность (U): ${result.subfactors.U.toFixed(1)} / 10
- Эмоция (E): ${result.subfactors.E.toFixed(1)} / 10
- Повторяемость (R): ${result.subfactors.R.toFixed(1)} / 10
- Капитал (K): ${result.subfactors.K.toFixed(1)} / 10
- Время окупаемости (T): ${result.subfactors.T.toFixed(1)} / 10
- Социальный (S): ${result.subfactors.S.toFixed(1)} / 10

Рыночные показатели:
- TAM: ${data.tam} млн. руб.
- SAM: ${data.sam} млн. руб.
- SOM: ${data.som} млн. руб.
- TAV (Порог автономии): ${data.tav} млн. руб.

Вердикт: ${result.interpretation}
    `.trim();

    navigator.clipboard.writeText(info).then(() => {
      setCopiedText(true);
      showToast('📋 Сводка результатов скопирована в буфер!', 'success');
      setTimeout(() => setCopiedText(false), 2000);
    }).catch(() => {
      showToast('❌ Ошибка при копировании', 'error');
    });
  };

  const results = calculateResult(data);
  const factorInterpretations = getFactorInterpretations(results.subfactors);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased pb-20 selection:bg-indigo-500 selection:text-white">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-6 py-4 rounded-xl shadow-xl border text-sm font-semibold transition-all ${
              notification.type === 'success' 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                : notification.type === 'error'
                ? 'bg-rose-50 text-rose-800 border-rose-200'
                : 'bg-indigo-50 text-indigo-800 border-indigo-200'
            }`}
          >
            <span className="text-base">
              {notification.type === 'success' ? '⚡' : notification.type === 'error' ? '💥' : 'ℹ️'}
            </span>
            <span>{notification.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* GLOBAL BACKGROUND ELEMENTS (HIDDEN IN PRINT) */}
      <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-indigo-900/10 via-transparent to-transparent pointer-events-none print:hidden -z-10" />

      {/* HEADER SECTION */}
      <header className="container max-w-6xl mx-auto pt-8 px-4 print:pt-4">
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl border border-indigo-900/30 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
          
          {/* Decorative background vectors */}
          <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
          <div className="absolute -left-10 -top-10 w-44 h-44 rounded-full bg-violet-500/10 blur-3xl pointer-events-none" />

          {/* Left badge fallback / logo placeholder */}
          <div className="flex-shrink-0 flex flex-col items-center justify-center bg-white/5 backdrop-blur-md px-5 py-4 rounded-2xl border border-white/10 w-full md:w-36 h-24 select-none">
            <span className="font-display font-extrabold text-2xl tracking-tight bg-gradient-to-r from-indigo-200 via-white to-indigo-100 bg-clip-text text-transparent">
              СКФУ
            </span>
            <span className="text-[9px] font-medium tracking-widest text-indigo-300 mt-1 uppercase text-center leading-tight">
              Технопарк
            </span>
          </div>

          <div className="flex-1 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-400/20 text-indigo-300 text-xs font-bold rounded-full mb-3 tracking-wide">
              <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
              <span>TRUSEK-6 FRAMEWORK</span>
            </div>
            <h1 className="font-display font-bold text-2xl md:text-3xl tracking-tight">
              Калькулятор индекса SSI бизнес-идеи
            </h1>
            <p className="text-indigo-200 text-sm mt-1.5 opacity-90 font-light max-w-2xl">
              Инструмент прединвестиционной экспресс-оценки самодостаточности технологических стартапов. Разработка для Технопарка Северо-Кавказского федерального университета.
            </p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-slate-400 text-xs mt-3.5 italic border-t border-white/5 pt-3">
              <span>Авторы методологии: <strong className="text-slate-300">Мандрица И.В., Мандрица О.В.</strong></span>
              <span className="hidden md:inline text-white/20">•</span>
              <span>Версия калькулятора: <strong className="text-indigo-300 font-mono">v2.0 (2026)</strong></span>
            </div>
          </div>

          {/* Right badge - Beautiful Lily mirroring the Technopark logo */}
          <div className="flex-shrink-0 flex items-center gap-4 flex-col md:flex-row">
            <div className="flex-shrink-0 flex items-center justify-center bg-white/5 backdrop-blur-md p-1.5 rounded-2xl border border-white/10 w-full md:w-36 h-24 select-none">
              <MiniLily subfactors={results.subfactors} />
            </div>

            {/* Right badge decoration */}
            <div className="hidden lg:flex flex-col items-end text-right border-l border-white/10 pl-5 shrink-0">
              <span className="text-xs uppercase tracking-widest text-indigo-400 font-semibold">Индекс SSI</span>
              <span className="font-display font-extrabold text-5xl text-white mt-1">
                {results.finalSsi.toFixed(1)}
              </span>
              <span className="text-[10px] text-slate-400 font-mono mt-1">Шкала от 0 до 10</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container max-w-6xl mx-auto px-4 mt-6">

        {/* SMART PASTE HINT BAR (HIDDEN IN PRINT) */}
        <section className="print:hidden mb-6">
          <div 
            onClick={handlePasteConsole}
            className="group relative bg-gradient-to-r from-violet-600 via-indigo-600 to-indigo-700 text-white p-4 rounded-2xl shadow-md cursor-pointer hover:shadow-lg hover:scale-[1.005] transition-all duration-300 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <FileJson className="w-5 h-5 text-indigo-100" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-sm sm:text-base tracking-wide flex items-center gap-1.5">
                    Умное автозаполнение по Ctrl + V
                  </h3>
                  <p className="text-xs text-indigo-100/90 font-light mt-0.5 max-w-xl">
                    Скопируйте сгенерированный ИИ (Claude / Qwen / ChatGPT) JSON анкеты и нажмите в любом месте экрана <kbd className="bg-white/15 px-1.5 py-0.5 rounded text-[10px] font-mono">Ctrl+V</kbd>. Лилия построится мгновенно.
                  </p>
                </div>
              </div>
              <button 
                type="button"
                className="bg-white/15 hover:bg-white/25 border border-white/20 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5"
              >
                <span>Интегрировать из буфера</span>
                <span className="font-mono text-[10px] bg-indigo-900/30 px-1 py-0.5 rounded text-white/80">Shift + Click</span>
              </button>
            </div>
          </div>
        </section>

        {/* NAVIGATION CONTROLS & UTILITY PRESETS */}
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 mb-6 print:hidden">
          
          {/* Main Module Tabs */}
          <div className="bg-slate-200/85 backdrop-blur-md p-1.5 rounded-xl flex gap-1 border border-slate-300/40 shrink-0 shadow-inner">
            <button
              onClick={() => setActiveTab('anketa')}
              className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-lg text-xs md:text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                activeTab === 'anketa' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
              }`}
            >
              <span>📝 Анкета стартапера</span>
            </button>
            <button
              onClick={() => setActiveTab('expert')}
              className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-lg text-xs md:text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                activeTab === 'expert' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
              }`}
            >
              <span className="whitespace-nowrap">🔬 Режим эксперта</span>
            </button>
            <button
              onClick={() => setActiveTab('result')}
              className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-lg text-xs md:text-sm font-semibold transition-all flex items-center justify-center gap-2 relative ${
                activeTab === 'result' 
                  ? 'bg-indigo-650 text-white shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
              }`}
            >
              <span>🌸 Результат</span>
              <span className="absolute -top-1.5 -right-1 block h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-100" />
            </button>
          </div>

          {/* Quick preset buttons */}
          <div className="flex items-center gap-2 justify-end">
            <button
              type="button"
              onClick={loadPresetDemo}
              className="px-3.5 py-2.5 text-xs bg-slate-100 border border-slate-200 rounded-xl hover:bg-slate-200 text-slate-700 font-semibold transition-all flex items-center gap-1.5 shadow-sm"
              title="Загрузить полностью заготовленные демонстрационные данные"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>Загрузить демо</span>
            </button>
            
            <button
              type="button"
              onClick={resetForm}
              className="px-3.5 py-2.5 text-xs bg-slate-100 border border-slate-200 rounded-xl hover:bg-rose-50 text-slate-600 hover:text-rose-700 font-semibold transition-all flex items-center gap-1.5 shadow-sm"
              title="Сбросить все показатели анкеты"
            >
              <Trash2 className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-500" />
              <span>Очистить</span>
            </button>
          </div>

        </div>

        {/* CONTAINER CARD FOR VIEWS */}
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 md:p-8">
          
          {/* ======================================================== */}
          {/* TAB: ANKETA (STUDENT FORM)                               */}
          {/* ======================================================== */}
          {activeTab === 'anketa' && (
            <div className="space-y-6">
              
              {/* Profile Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50/70 p-5 rounded-2xl border border-slate-100 mb-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-700 tracking-wide uppercase">Название вашего стартапа</label>
                  <input 
                    type="text" 
                    value={data.name} 
                    onChange={e => handleInputChange('name', e.target.value)}
                    placeholder="Например: Цифровой логистический хаб"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:border-indigo-500 focus:outline-none transition-all font-semibold"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-700 tracking-wide uppercase">ФИО разработчика (стартапера)</label>
                  <input 
                    type="text" 
                    value={data.author} 
                    onChange={e => handleInputChange('author', e.target.value)}
                    placeholder="Иванов Иван Иванович"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:border-indigo-500 focus:outline-none transition-all font-semibold"
                  />
                </div>
              </div>

              {/* FACTOR U */}
              <div className="factor-section bg-gradient-to-br from-indigo-50/20 to-slate-50 border-l-[6px] border-indigo-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-indigo-900 flex items-center gap-1.5">
                      <span>U · Утилитарность</span>
                      <span className="text-xs bg-indigo-100 text-indigo-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 15%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Фактор определяет силу реальной зависимости покупателя от вашего продукта (изделия, услуги, товара). Чем сильнее "боль" клиента без вашего решения, тем выше маркер фактора.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл U:</span>
                    <div className="text-xl font-black text-indigo-600 font-mono">
                      {calculateSubfactors(data).U.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* U1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>U₁ — Стоимость альтернативы (в рублях)</span>
                        <Tooltip text="Сумма, которую клиент тратит на решение проблемы текущими способами, либо сумма штрафов за отсутствие решения." />
                      </label>
                      <span className="font-mono text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.u1, 0, 300000).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      У конкурентов стоит 300 руб., вы предлагаете за 127 руб. Клиент экономит 173 руб. на единицу → введите <strong className="text-indigo-600 font-mono">173</strong> в качестве альтернативной разницы. Максимальный лимит для шкалы равен 300&nbsp;000 руб.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="300000" 
                        step="500" 
                        value={data.u1}
                        onChange={e => handleNumberInput('u1', e.target.value)}
                        className="flex-1 accent-indigo-600 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.u1} 
                        onChange={e => handleNumberInput('u1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* U2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>U₂ — Эпизодов потребности в год</span>
                        <Tooltip text="Как часто в году возникает острая необходимость воспользоваться продуктом." />
                      </label>
                      <span className="font-mono text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.u2, 1, 52).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Частота циклов плановой покупки вашего изделия, работы, услуги, товара. Подсказка: Раз в год = 1 цикл · Раз в месяц = 12 · Раз в неделю = 52 · Ежедневно = 365. Нормализация от 1 до 52 событий.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="1" 
                        max="365" 
                        step="1" 
                        value={data.u2}
                        onChange={e => handleNumberInput('u2', e.target.value)}
                        className="flex-1 accent-indigo-600 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.u2} 
                        onChange={e => handleNumberInput('u2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* FACTOR E */}
              <div className="factor-section bg-gradient-to-br from-amber-50/20 to-slate-50 border-l-[6px] border-amber-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-amber-950 flex items-center gap-1.5">
                      <span>E · Эмоция</span>
                      <span className="text-xs bg-amber-100 text-amber-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 20%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Определяет глубину эмоционального вовлечения клиента, преданности вашему продукту (изделию, услуге, товару) и готовность доплачивать премию за Ваш бренд.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл E:</span>
                    <div className="text-xl font-black text-amber-600 font-mono">
                      {calculateSubfactors(data).E.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* E1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>E₁ — Минут взаимодействия за сессию</span>
                        <Tooltip text="Продолжительность непосредственного фокусного контакта пользователя с ценностью продукта за один раз." />
                      </label>
                      <span className="font-mono text-xs bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.e1, 0, 60).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Время контакта. Для приложений — время у экрана. Консервы или еда — время трапезы (в среднем 20 минут). Нормализация шкалы от 0 до 60 минут.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="120" 
                        step="1" 
                        value={data.e1}
                        onChange={e => handleNumberInput('e1', e.target.value)}
                        className="flex-1 accent-amber-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.e1} 
                        onChange={e => handleNumberInput('e1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* E2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>E₂ — Соотношение Наша цена / Цена конкурента</span>
                        <Tooltip text="Отношение вашей цены к средней рыночной цене главных конкурентов." />
                      </label>
                      <span className="font-mono text-xs bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.e2, 0, 2).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Пример: 127 руб / 300 руб = <strong className="font-mono">0.42</strong> (дешевле альтернативы, высокая привлекательность). Лимит шкалы отношений от 0 до 2.0.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0.1" 
                        max="3" 
                        step="0.05" 
                        value={data.e2}
                        onChange={e => handleNumberInput('e2', e.target.value)}
                        className="flex-1 accent-amber-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        step="0.01" 
                        value={data.e2} 
                        onChange={e => handleNumberInput('e2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* FACTOR R */}
              <div className="factor-section bg-gradient-to-br from-rose-50/20 to-slate-50 border-l-[6px] border-rose-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-rose-950 flex items-center gap-1.5">
                      <span>R · Повторяемость</span>
                      <span className="text-xs bg-rose-100 text-rose-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 15%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Отражает уровень удержания клиентов вашей фокус-группы, частоту регулярных покупок ими вашего изделия (услуги, работ, товара), что формирует жизнеспособность финансовой пропорции LTV/CAC (LTV, Lifetime Value — пожизненная ценность клиента / CAC, Customer Acquisition Cost — стоимость привлечения клиента).</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл R:</span>
                    <div className="text-xl font-black text-rose-600 font-mono">
                      {calculateSubfactors(data).R.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* R1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>R₁ — Покупок в год (одним клиентом)</span>
                        <Tooltip text="Какое среднее количество заказов совершает один лояльный покупатель за 12 месяцев." />
                      </label>
                      <span className="font-mono text-xs bg-rose-50 text-rose-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.r1, 0, 52).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Консервы: ~6 раз в год · Платная подписка: ~12 раз · Новая одежда: 2–3 раза · Архитектура/Дизайн: 0.2 раза. Шкала нормирования от 0 до 52 повторных покупок.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="52" 
                        step="1" 
                        value={data.r1}
                        onChange={e => handleNumberInput('r1', e.target.value)}
                        className="flex-1 accent-rose-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.r1} 
                        onChange={e => handleNumberInput('r1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* R2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>R₂ — Соотношение LTV / CAC (LTV — пожизненная ценность клиента / CAC — стоимость привлечения клиента)</span>
                        <Tooltip text="Ценность жизненного цикла клиента к стоимости его привлечения. Ключевой критерий масштабируемости." />
                      </label>
                      <span className="font-mono text-xs bg-rose-50 text-rose-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.r2, 0, 10).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Пример: LTV 15 000 руб, CAC 3 000 руб → Ваше соотношение 5.0. Инвестиционная норма: более 3.0. Если вы не научились считать CAC → введите значение <strong className="font-mono">3.0</strong>. Максимум 10.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="15" 
                        step="0.1" 
                        value={data.r2}
                        onChange={e => handleNumberInput('r2', e.target.value)}
                        className="flex-1 accent-rose-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        step="0.01" 
                        value={data.r2} 
                        onChange={e => handleNumberInput('r2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* FACTOR K */}
              <div className="factor-section bg-gradient-to-br from-emerald-50/20 to-slate-50 border-l-[6px] border-emerald-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-emerald-950 flex items-center gap-1.5">
                      <span>K · Капитал</span>
                      <span className="text-xs bg-emerald-100 text-emerald-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 15%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Определяет объем требуемых капитальных инвестиций (CAPEX, Capital Expenditure — капитальные расходы) на запуск Вашего проекта и уровень маржинальности Ваших бизнес-процессов.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл K:</span>
                    <div className="text-xl font-black text-emerald-600 font-mono">
                      {calculateSubfactors(data).K.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* K1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>K₁ — Стартовые затраты, CAPEX (капитальные расходы), тыс. руб.</span>
                        <Tooltip text="Инвестиции на закупку оборудования, разработку MVP софта, аренду помещений до первых продаж." />
                      </label>
                      <span className="font-mono text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.k1, 0, 5000, true).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Меньше вложений = сильнее жизнеспособность. До 300 тыс = супер. 300–1000 тыс = стандарт. 1–5 млн = сложно. Шкала инвертирована, максимальный лимит — 5 000 тыс (5 млн руб).
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="5000" 
                        step="50" 
                        value={data.k1}
                        onChange={e => handleNumberInput('k1', e.target.value)}
                        className="flex-1 accent-emerald-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.k1} 
                        onChange={e => handleNumberInput('k1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* K2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>K₂ — Маржинальность продукции (%)</span>
                        <Tooltip text="Какая доля выручки остается после вычета прямых расходов на производство товара или оказание услуги (COGS)." />
                      </label>
                      <span className="font-mono text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.k2, 0, 80).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Пример расчета: Цена 127 руб, себестоимость 95 руб → маржа: <strong className="font-mono">25%</strong>. IT-сервисы: 60–80%. Пищевое производство: 20-30%. Шкала нормирована до 80%.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        step="1" 
                        value={data.k2}
                        onChange={e => handleNumberInput('k2', e.target.value)}
                        className="flex-1 accent-emerald-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.k2} 
                        onChange={e => handleNumberInput('k2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* FACTOR T */}
              <div className="factor-section bg-gradient-to-br from-purple-50/20 to-slate-50 border-l-[6px] border-purple-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-purple-950 flex items-center gap-1.5">
                      <span>T · Время окупаемости</span>
                      <span className="text-xs bg-purple-100 text-purple-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 20%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Оценивает скорость разгона вашего проекта до нормы прибыли выше чем у конкурентов и общий срок возврата (окупаемости) стартового первоначального капитала.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл T:</span>
                    <div className="text-xl font-black text-purple-600 font-mono">
                      {calculateSubfactors(data).T.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* T1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>T₁ — Месяцев до EBITDA+ (Окупаемость OPEX)</span>
                        <Tooltip text="Сколько реальных месяцев пройдет от старта до выхода текущей выручки выше ежемесячных операционных расходов (зарплаты, аренда)." />
                      </label>
                      <span className="font-mono text-xs bg-purple-50 text-purple-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.t1, 1, 36, true).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      До 6 месяцев — образцово. 6-12 мес — штатно. Более 24 месяцев — высокий износ ресурсов. Инвертированная шкала нормирована в диапазоне от 1 до 36 мес.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="1" 
                        max="36" 
                        step="1" 
                        value={data.t1}
                        onChange={e => handleNumberInput('t1', e.target.value)}
                        className="flex-1 accent-purple-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.t1} 
                        onChange={e => handleNumberInput('t1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* T2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>T₂ — Месяцев до полной окупаемости CAPEX (капитальных расходов)</span>
                        <Tooltip text="Через сколько месяцев проект вернет все стартовые инвестиции и выйдет в чистую прибыль." />
                      </label>
                      <span className="font-mono text-xs bg-purple-50 text-purple-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.t2, 1, 60, true).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Пример: стартовые вложения 490 тыс., плановая прибыль 32 тыс/мес → окупаемость 490/32 = 15 мес. Оптимально до 12 месяцев. Инвертированная нормализация от 1 до 60 месяцев.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="1" 
                        max="60" 
                        step="1" 
                        value={data.t2}
                        onChange={e => handleNumberInput('t2', e.target.value)}
                        className="flex-1 accent-purple-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.t2} 
                        onChange={e => handleNumberInput('t2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* FACTOR S */}
              <div className="factor-section bg-gradient-to-br from-teal-50/20 to-slate-50 border-l-[6px] border-teal-500 p-6 rounded-2xl">
                <div className="flex justify-between items-start flex-wrap gap-4 mb-2">
                  <div>
                    <h3 className="font-display font-bold text-lg text-teal-950 flex items-center gap-1.5">
                      <span>S · Социальный</span>
                      <span className="text-xs bg-teal-100 text-teal-800 font-mono px-2 py-0.5 rounded">весовой коэффициент: 15%</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Фактор оценивает силу &quot;сарафанного маркетинга&quot; как реакция на ваш продукт (услугу, изделие, товар), некую самоспособность органически (естественно) распространяться и общий уровень удовлетворенности клиентов (NPS) вашим изделием (продукцией, услугой, работой).</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 font-mono">Сводный балл S:</span>
                    <div className="text-xl font-black text-teal-600 font-mono">
                      {calculateSubfactors(data).S.toFixed(1)} <span className="text-xs text-slate-400 font-normal">/ 10</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  {/* S1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>S₁ — Доля клиентов по рекомендации (%)</span>
                        <Tooltip text="Какой процент целевого трафика вашей воронки продаж покупает продукт благодаря органическому сарафанному радио." />
                      </label>
                      <span className="font-mono text-xs bg-teal-50 text-teal-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.s1, 0, 100).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Из 100 новых клиентов — сколько пришли по отзывам и рекомендациям друзей? Если вы еще не запустились и не проводили замеры → введите <strong className="font-mono">0</strong>. Диапазон от 0% до 100%.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        step="1" 
                        value={data.s1}
                        onChange={e => handleNumberInput('s1', e.target.value)}
                        className="flex-1 accent-teal-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.s1} 
                        onChange={e => handleNumberInput('s1', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>

                  {/* S2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <label className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span>S₂ — Индекс потребительской лояльности NPS</span>
                        <Tooltip text="Net Promoter Score: доля активных сторонников продукта за вычетом критиков. Измеряется от -100 до +100." />
                      </label>
                      <span className="font-mono text-xs bg-teal-50 text-teal-700 px-2 py-0.5 rounded font-bold">
                        {norm(data.s2, -100, 100).toFixed(1)} / 10
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      60% рекомендуют товар, 10% недовольны → NPS = 50. Отсутствие полевой статистики или опросов → введите значение <strong className="font-mono">0</strong>. Шкала измерения от -100 до +100.
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="-100" 
                        max="100" 
                        step="5" 
                        value={data.s2}
                        onChange={e => handleNumberInput('s2', e.target.value)}
                        className="flex-1 accent-teal-500 cursor-ew-resize h-1.5 bg-slate-200 rounded-lg"
                      />
                      <input 
                        type="number" 
                        value={data.s2} 
                        onChange={e => handleNumberInput('s2', e.target.value)}
                        className="w-24 px-3 py-1.5 text-right font-mono border border-slate-300 rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>


              {/* MARKET BLOCK (TAM SAM SOM TAV) */}
              <div className="factor-section bg-gradient-to-br from-amber-500/5 to-slate-50 border-l-[6px] border-amber-600 p-6 rounded-2xl">
                <div className="mb-2">
                  <h3 className="font-display font-bold text-lg text-amber-900 flex items-center gap-1.5">
                    <span>M · Показатели рынка для модификатора MEI</span>
                    <span className="text-xs bg-amber-600/10 text-amber-800 font-mono px-2 py-0.5 rounded">млн рублей</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">Определяет рыночную жизнеспособность вашей бизнес-идеи (стартапа) и внутреннее качество вашей бизнес-идеи на только вашей нише рынке, которая формирует финансовый &quot;насос&quot; от вашего проекта и принесет стабильную финансовую автономию.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-5">
                  
                  {/* TAM */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <span>TAM (Весь рынок РФ)</span>
                      <Tooltip text="Total Addressable Market: Финансовый объем потенциального спроса по всей стране в вашей категории." />
                    </label>
                    <input 
                      type="number" 
                      value={data.tam} 
                      onChange={e => handleNumberInput('tam', e.target.value)}
                      placeholder="млн руб в год"
                      className="w-full px-4 py-2 border border-slate-300 rounded-xl text-sm font-semibold font-mono"
                    />
                    <div className="text-[10px] text-slate-400">Объем всей ниши. Например: 15 000 млн.</div>
                  </div>

                  {/* SAM */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <span>SAM (Ваш сегмент рынка)</span>
                      <Tooltip text="Serviceable Available Market: Доля рынка, доступная для имеющихся каналов сбыта и дистрибуции." />
                    </label>
                    <input 
                      type="number" 
                      value={data.sam} 
                      onChange={e => handleNumberInput('sam', e.target.value)}
                      placeholder="млн руб в год"
                      className="w-full px-4 py-2 border border-slate-300 rounded-xl text-sm font-semibold font-mono"
                    />
                    <div className="text-[10px] text-slate-400">Достижимый сегмент. Например: 450 млн.</div>
                  </div>

                  {/* SOM */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <span>SOM (Реальный захват 3 года)</span>
                      <Tooltip text="Serviceable Obtainable Market: Консервативный плановый объем продаж, который вы точно займете своей сетью за 3 года." />
                    </label>
                    <input 
                      type="number" 
                      value={data.som} 
                      onChange={e => handleNumberInput('som', e.target.value)}
                      placeholder="млн руб в год"
                      className="w-full px-4 py-2 border border-slate-300 rounded-xl text-sm font-semibold font-mono"
                    />
                    <div className="text-[10px] text-slate-400">Реалистичный план продаж. Например: 18 млн.</div>
                  </div>

                  {/* TAV */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <span>TAV (Порог автономии)</span>
                      <Tooltip text="Threshold Autonomy Value: Минимально необходимый объем годовой маржинальной прибыли для покрытия всех OPEX расходов бизнеса." />
                    </label>
                    <input 
                      type="number" 
                      value={data.tav} 
                      onChange={e => handleNumberInput('tav', e.target.value)}
                      placeholder="млн руб в год"
                      className="w-full px-4 py-2 border border-slate-300 rounded-xl text-sm font-semibold font-mono"
                    />
                    <div className="text-[10px] text-slate-400">Точка окупаемости в год. Например: 4.5 млн.</div>
                  </div>

                </div>
              </div>


              {/* ACTIONS BOTTOM BLOCK */}
              <div className="flex flex-wrap items-center justify-between border-t border-slate-100 pt-6 gap-4">
                <div className="flex items-center gap-3">
                  <label className="bg-slate-100 hover:bg-slate-200 border border-slate-200/80 px-4 py-3 rounded-xl text-xs font-bold cursor-pointer transition-all flex items-center gap-2">
                    <Upload className="w-4 h-4 text-slate-500" />
                    <span>Импортировать .JSON анкеты</span>
                    <input 
                      type="file" 
                      accept=".json" 
                      onChange={handleFileImport}
                      className="hidden" 
                    />
                  </label>
                  <button
                    type="button"
                    onClick={exportToJsonFile}
                    className="bg-slate-100 hover:bg-slate-200 border border-slate-200/80 px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2"
                  >
                    <FileJson className="w-4 h-4 text-slate-500" />
                    <span>Скачать .JSON файл анкеты</span>
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2"
                    title="Очистить все поля анкеты для новой бизнес-идеи"
                  >
                    <Trash2 className="w-4 h-4 text-rose-500" />
                    <span>Очистить для новой бизнес-идеи</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('result');
                    showToast('🌸 Расчет индекса SSI и рендер лилии завершен!', 'success');
                  }}
                  className="bg-gradient-to-r from-indigo-600 to-indigo-800 text-white hover:from-indigo-700 hover:to-indigo-950 px-6 py-3.5 rounded-xl text-sm font-black tracking-wide shadow-md transition-all shrink-0 hover:scale-[1.02] flex items-center gap-2"
                >
                  <span>🌸 Построить Лилию Самодостаточности</span>
                  <span className="text-xs bg-indigo-500/30 px-2 py-0.5 rounded text-white/90">→</span>
                </button>
              </div>

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB: EXPERT VIEW (SYNCED WEIGHTED FORMS)                 */}
          {/* ======================================================== */}
          {activeTab === 'expert' && (
            <div className="space-y-6">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3">
                <Info className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-600 leading-relaxed">
                  <strong className="text-slate-800">Режим эксперта:</strong> Все весовые показатели жестко соответствуют зафиксированной математической модели системы <strong className="text-indigo-600">TRUSEK-6</strong>. Здесь вы можете анализировать структуру весов и напрямую изменять входящие переменные. Данные автоматически дублируются во вкладку анкеты стартапера.
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* U SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 15%</span>
                  <h4 className="font-bold text-indigo-950 font-display">Фактор U — Утилитарность ценностного предложения</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Стоимость альтернативы (U₁)</span>
                        <span className="font-mono text-indigo-600 font-bold">{data.u1} руб.</span>
                      </div>
                      <input 
                        type="range" min="0" max="300000" step="1000" value={data.u1} 
                        onChange={e => handleNumberInput('u1', e.target.value)}
                        className="w-full accent-indigo-600 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Эпизодов потребности в год (U₂)</span>
                        <span className="font-mono text-indigo-600 font-bold">{data.u2}</span>
                      </div>
                      <input 
                        type="range" min="1" max="365" step="1" value={data.u2} 
                        onChange={e => handleNumberInput('u2', e.target.value)}
                        className="w-full accent-indigo-600 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

                {/* E SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-amber-100 text-amber-850 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 20%</span>
                  <h4 className="font-bold text-slate-900 font-display">Фактор E — Эмоциональное превосходство бренд-контакта</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Минут взаимодействия (E₁)</span>
                        <span className="font-mono text-amber-700 font-bold">{data.e1} мин</span>
                      </div>
                      <input 
                        type="range" min="0" max="120" step="1" value={data.e1} 
                        onChange={e => handleNumberInput('e1', e.target.value)}
                        className="w-full accent-amber-500 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Соотношение цен (E₂)</span>
                        <span className="font-mono text-amber-700 font-bold">{data.e2}</span>
                      </div>
                      <input 
                        type="range" min="0.1" max="3" step="0.05" value={data.e2} 
                        onChange={e => handleNumberInput('e2', e.target.value)}
                        className="w-full accent-amber-500 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

                {/* R SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-rose-100 text-rose-800 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 15%</span>
                  <h4 className="font-bold text-rose-950 font-display">Фактор R — Коэффициент удержания и повторяемость</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Покупок в год (R₁)</span>
                        <span className="font-mono text-rose-600 font-bold">{data.r1} покупок</span>
                      </div>
                      <input 
                        type="range" min="0" max="52" step="1" value={data.r1} 
                        onChange={e => handleNumberInput('r1', e.target.value)}
                        className="w-full accent-rose-500 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Пропорция LTV/CAC (LTV — пожизненная ценность / CAC — стоимость привлечения) (R₂)</span>
                        <span className="font-mono text-rose-600 font-bold">{data.r2}</span>
                      </div>
                      <input 
                        type="range" min="0" max="15" step="0.1" value={data.r2} 
                        onChange={e => handleNumberInput('r2', e.target.value)}
                        className="w-full accent-rose-500 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

                {/* K SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-emerald-100 text-emerald-850 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 15%</span>
                  <h4 className="font-bold text-slate-900 font-display">Фактор K — Ограничения по капиталу CAPEX (капитальные расходы)</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Стартовые затраты K₁ (CAPEX — капитальные расходы)</span>
                        <span className="font-mono text-emerald-700 font-bold">{data.k1} тыс. руб.</span>
                      </div>
                      <input 
                        type="range" min="0" max="5000" step="50" value={data.k1} 
                        onChange={e => handleNumberInput('k1', e.target.value)}
                        className="w-full accent-emerald-500 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Прямая маржинальность K₂ (%)</span>
                        <span className="font-mono text-emerald-700 font-bold">{data.k2} %</span>
                      </div>
                      <input 
                        type="range" min="1" max="100" step="1" value={data.k2} 
                        onChange={e => handleNumberInput('k2', e.target.value)}
                        className="w-full accent-emerald-500 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

                {/* T SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 20%</span>
                  <h4 className="font-bold text-purple-950 font-display">Фактор T — Скорость окупаемости инвестиций</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Месяцев до EBITDA+ (T₁)</span>
                        <span className="font-mono text-purple-600 font-bold">{data.t1} мес</span>
                      </div>
                      <input 
                        type="range" min="1" max="36" step="1" value={data.t1} 
                        onChange={e => handleNumberInput('t1', e.target.value)}
                        className="w-full accent-purple-500 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Полная финансовая окупаемость (T₂)</span>
                        <span className="font-mono text-purple-600 font-bold">{data.t2} мес</span>
                      </div>
                      <input 
                        type="range" min="1" max="60" step="1" value={data.t2} 
                        onChange={e => handleNumberInput('t2', e.target.value)}
                        className="w-full accent-purple-500 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

                {/* S SECTION */}
                <div className="p-5 border border-slate-100 bg-slate-50/50 rounded-2xl relative">
                  <span className="absolute top-4 right-4 bg-teal-100 text-teal-800 px-2 py-0.5 rounded text-xs font-mono font-bold">Вес: 15%</span>
                  <h4 className="font-bold text-teal-950 font-display">Фактор S — Социальное вовлечение и сарафан</h4>
                  
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Рекомендательный трафик (S₁)</span>
                        <span className="font-mono text-teal-600 font-bold">{data.s1} %</span>
                      </div>
                      <input 
                        type="range" min="0" max="100" step="1" value={data.s1} 
                        onChange={e => handleNumberInput('s1', e.target.value)}
                        className="w-full accent-teal-500 cursor-ew-resize h-1"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Потребительская лояльность NPS (S₂)</span>
                        <span className="font-mono text-teal-600 font-bold">{data.s2}</span>
                      </div>
                      <input 
                        type="range" min="-100" max="100" step="5" value={data.s2} 
                        onChange={e => handleNumberInput('s2', e.target.value)}
                        className="w-full accent-teal-500 cursor-ew-resize h-1"
                      />
                    </div>
                  </div>
                </div>

              </div>

              {/* MARKET EXP MOD */}
              <div className="p-6 bg-slate-900 text-slate-100 rounded-3xl mt-6">
                <h4 className="font-bold font-display text-base text-amber-400 mb-4 flex items-center gap-1.5">
                  <span>Рыночная емкость (Модификатор MEI)</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400">TAM (млн руб)</span>
                    <input 
                      type="number" value={data.tam} onChange={e => handleNumberInput('tam', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg py-1.5 px-3 text-sm text-amber-300 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400">SAM (млн руб)</span>
                    <input 
                      type="number" value={data.sam} onChange={e => handleNumberInput('sam', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg py-1.5 px-3 text-sm text-yellow-100 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400">SOM (млн руб)</span>
                    <input 
                      type="number" value={data.som} onChange={e => handleNumberInput('som', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg py-1.5 px-3 text-sm text-yellow-100 font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400">TAV (Порог автономии)</span>
                    <input 
                      type="number" value={data.tav} onChange={e => handleNumberInput('tav', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg py-1.5 px-3 text-sm text-yellow-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                  title="Очистить все поля анкеты для новой бизнес-идеи"
                >
                  <Trash2 className="w-4 h-4 text-rose-500" />
                  <span>Очистить для новой идеи</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('result');
                    showToast('🎛️ Расчеты обновлены для экспертного вида!', 'success');
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl font-bold text-xs"
                >
                  Выйти на страницу результатов →
                </button>
              </div>

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB: RESULT (DETAILED FLOWER GRID & RECS)                 */}
          {/* ======================================================== */}
          {activeTab === 'result' && (
            <div className="space-y-8 print:space-y-6">

              {/* CRITICAL RENDER RESULTS CARD */}
              <div className="relative text-white rounded-3xl p-6 md:p-8 overflow-hidden shadow-lg border border-slate-800" 
                   style={{ background: `linear-gradient(135deg, ${results.color} 0%, #0f172a 100%)` }}>
                
                {/* Visual decoration inside result report banner */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none" />

                <div className="relative z-10 flex flex-col md:flex-row items-center md:justify-between gap-6">
                  
                  <div className="text-center md:text-left">
                    <span className="bg-white/15 backdrop-blur-md text-[10px] font-bold tracking-widest uppercase py-1 px-3 rounded-full text-indigo-100">
                      Прогноз самодостаточности бизнес идеи стартапа на основе модели SSI
                    </span>
                    <h2 className="font-display font-black text-3xl md:text-4xl mt-3 tracking-tight">
                      {data.name || 'Проект без названия'}
                    </h2>
                    <p className="text-sm font-medium text-slate-300 mt-1 italic">
                      Автор разработки: {data.author || 'Не указан'}
                    </p>
                    <p className="text-xs md:text-sm text-slate-200 mt-4 leading-relaxed max-w-2xl font-light">
                      {results.interpretation}
                    </p>
                  </div>

                  <div className="flex flex-col items-center shrink-0 bg-white/10 backdrop-blur-md px-6 py-5 rounded-2xl border border-white/15 w-full md:w-56 text-center shadow-inner">
                    <span className="text-[10px] tracking-widest uppercase text-slate-300 font-bold whitespace-nowrap">Финальный Индекс SSI</span>
                    <span className="font-display font-extrabold text-6xl text-white my-1.5 leading-none">
                      {results.finalSsi.toFixed(2)}
                    </span>
                    <span className="text-[11px] text-indigo-200/90 font-medium">
                      из 10.0 возможных
                    </span>
                  </div>

                </div>

                {/* HORIZONTAL SCALE BAR VISUALIZER */}
                <div className="mt-6 border-t border-white/10 pt-6">
                  <div className="relative flex justify-between text-xs text-slate-200 font-bold mb-3 px-1">
                    <span>0.0 (Критический)</span>
                    <span>3.5</span>
                    <span>5.0</span>
                    <span>6.5</span>
                    <span>7.5</span>
                    <span>8.5</span>
                    <span>10.0 (Образцовый)</span>
                  </div>
                  
                  {/* Visual slider track enlarged strictly by 3 times (from h-2.5 to h-7.5 / 30px) */}
                  <div className="h-[30px] bg-white/20 rounded-full overflow-hidden relative shadow-inner border border-white/10">
                    
                    {/* The colored background representing scale milestones */}
                    <div className="absolute inset-0 bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-500 opacity-95" />
                    
                    {/* The white dot cursor/slider handle enlarged 3 times (from w-4 h-4 to w-12 h-12) with score value inside! */}
                    <div 
                      className="absolute top-1/2 -translate-y-1/2 w-12 h-12 bg-white border-[3px] border-slate-900 rounded-full shadow-2xl transition-all duration-1000 ease-out flex items-center justify-center cursor-pointer select-none"
                      style={{ left: `${Math.min(94, Math.max(3, results.finalSsi * 10))}%`, transform: 'translate(-50%, -50%)' }}
                    >
                      <span className="text-slate-950 font-mono font-black text-xs">
                        {results.finalSsi.toFixed(1)}
                      </span>
                    </div>
                  </div>
                </div>

              </div>

              {/* LILY FLOWER SVG GRAPHICS & INTRO */}
              <div className="space-y-8">
                
                {/* Vector Canvas Container - Expanded size for premium visual fidelity and layout clarity */}
                <div className="flex flex-col items-center justify-center bg-slate-50 border border-slate-200/60 p-6 md:p-10 rounded-3xl shadow-sm relative min-h-[640px]">
                  <div className="absolute top-4 left-4 text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
                    Лилия бизнес идеи TRUSEK-6 (+Оценки подфакторов)
                  </div>
                  
                  <div className="w-full max-w-[820px] aspect-square relative selection:bg-none mt-4">
                    <LilySvg subfactors={results.subfactors} ssi={results.finalSsi} data={data} />
                  </div>

                  <div className="text-center text-xs text-slate-500 max-w-xl mt-6 font-light leading-relaxed">
                    Каждый лепесток представляет долю нормированного фактора. Оценки 12 подфакторов нанесены на внешние карточки каждого сектора. Сбалансированный крупный цветок символизирует устойчивую бизнес-модель.
                  </div>
                </div>

                {/* SIDE STATS AND INTERACTIVE KEY LEGEND - Now rendered in a modern 2-column grid beneath the majestic flower! */}
                <div className="space-y-4">
                  <h3 className="font-display font-extrabold text-lg text-slate-950 uppercase tracking-wide border-b border-slate-100 pb-2">
                    Сводный факторный профиль
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {factorInterpretations.map(f => (
                      <div 
                        key={f.key}
                        className={`p-3.5 rounded-xl border flex items-center justify-between gap-4 transition-all hover:shadow-xs group ${
                          f.status === 'strong' 
                            ? 'bg-emerald-50/50 border-emerald-100' 
                            : f.status === 'medium'
                            ? 'bg-amber-50/20 border-amber-100'
                            : 'bg-rose-50/40 border-rose-100'
                        }`}
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-slate-500 uppercase">
                              {f.key}
                            </span>
                            <span className="font-bold text-xs sm:text-sm text-slate-800">
                              {f.name.split(' ')[1]}
                            </span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              f.status === 'strong' 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : f.status === 'medium'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {f.statusLabel}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5 group-hover:line-clamp-none transition-all">
                            {f.desc}
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-slate-400 block font-mono">Балл</span>
                          <span className={`font-mono font-extrabold text-base ${
                            f.status === 'strong' 
                              ? 'text-emerald-700' 
                              : f.status === 'medium'
                              ? 'text-amber-700'
                              : 'text-rose-700'
                          }`}>
                            {f.score.toFixed(1)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* MARKET MODIFIER MEI STATS PANEL */}
              <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 relative overflow-hidden border border-slate-850">
                <div className="absolute -left-6 -bottom-6 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
                
                <div className="relative z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
                    <h3 className="font-display font-semibold uppercase tracking-wider text-amber-400 text-xs sm:text-sm">
                      Рыночный модификатор MEI (Market Efficiency Index)
                    </h3>
                  </div>

                  <p className="text-xs text-slate-300 mt-2 font-light leading-relaxed max-w-4xl">
                    Рыночный модификатор калибрует базовый индекс <strong className="text-indigo-300">SSI</strong> на основе масштаба доступного сегмента и реалистичности планов по взятию точки безубыточности. Если соотношение планируемой выручки (<strong className="text-amber-200">SOM</strong>) к порогу автономии операционных расходов (<strong className="text-emerald-200 font-mono">TAV</strong>) меньше единицы — коэффициент опускается до <strong className="text-orange-400 font-mono">0.3</strong>, ослабляя общую оценку стартапа.
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
                    <div className="bg-white/5 border border-white/5 p-3 rounded-2xl text-center">
                      <span className="text-[10px] text-slate-400 block tracking-wide uppercase">TAM</span>
                      <span className="font-mono text-base font-extrabold mt-1 block">
                        {data.tam ? `${data.tam} млн` : '—'}
                      </span>
                    </div>
                    <div className="bg-white/5 border border-white/5 p-3 rounded-2xl text-center">
                      <span className="text-[10px] text-slate-400 block tracking-wide uppercase">SAM</span>
                      <span className="font-mono text-base font-extrabold mt-1 block">
                        {data.sam ? `${data.sam} млн` : '—'}
                      </span>
                    </div>
                    <div className="bg-white/5 border border-white/5 p-3 rounded-2xl text-center">
                      <span className="text-[10px] text-slate-400 block tracking-wide uppercase">SOM</span>
                      <span className="font-mono text-base font-extrabold mt-1 block text-amber-300">
                        {data.som ? `${data.som} млн` : '—'}
                      </span>
                    </div>
                    <div className="bg-white/5 border border-white/5 p-3 rounded-2xl text-center">
                      <span className="text-[10px] text-slate-400 block tracking-wide uppercase">TAV (Порог)</span>
                      <span className="font-mono text-base font-extrabold mt-1 block text-emerald-300">
                        {data.tav ? `${data.tav} млн` : '—'}
                      </span>
                    </div>
                    <div className="bg-indigo-900/40 border border-indigo-500/20 col-span-2 md:col-span-1 p-3 rounded-2xl text-center group">
                      <span className="text-[10px] text-indigo-300 block font-bold tracking-wide uppercase">MEI Коэф.</span>
                      <span className="font-mono text-xl font-bold mt-1 block text-indigo-200">
                        × {results.mei.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* DYNAMIC SYSTEM RECOMMENDATIONS */}
              <div className="bg-indigo-50/30 p-6 md:p-8 rounded-3xl border border-indigo-100/60">
                <h3 className="font-display font-extrabold text-indigo-900 text-lg flex items-center gap-2 mb-4">
                  <span>🎯 Векторы стратегического развития</span>
                </h3>

                <div className="space-y-4">
                  {factorInterpretations.some(f => f.status !== 'strong') ? (
                    factorInterpretations
                      .filter(f => f.status !== 'strong')
                      .map(f => (
                        <div 
                          key={f.key}
                          className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex gap-4 items-start"
                        >
                          <div className={`mt-0.5 shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            f.status === 'weak' 
                              ? 'bg-rose-100 text-rose-850' 
                              : 'bg-amber-100 text-amber-850'
                          }`}>
                            {f.key}
                          </div>
                          <div>
                            <h4 className="font-bold text-xs sm:text-sm text-slate-900">
                              Рекомендация по фактору {f.name}
                            </h4>
                            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed font-light">
                              {f.advice}
                            </p>
                          </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-emerald-50 text-emerald-800 p-4 rounded-2xl border border-emerald-100 text-center font-bold text-sm">
                      🎉 Все факторы устойчивости превышают 7.0 баллов! Ваша бизнес-модель идеально сбалансирована — выходите на крупные инвестиционные раунды!
                    </div>
                  )}
                </div>
              </div>

              {/* REPORT PRINT & ACTION TOOLS */}
              <div className="flex flex-wrap items-center justify-end gap-3 border-t border-slate-100 pt-6 print:hidden">
                
                <button
                  type="button"
                  onClick={() => copyResultsText(results)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-4 py-3 rounded-xl text-xs transition-all flex items-center gap-1.5"
                >
                  <Copy className="w-4 h-4 text-slate-400" />
                  <span>{copiedText ? 'Скопировано!' : 'Копировать сводку в буфер'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-4 py-3 rounded-xl text-xs transition-all flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4 text-slate-400" />
                  <span>Распечатать прогноз на основе модели SSI</span>
                </button>

                <button
                  type="button"
                  onClick={exportToJsonFile}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-4 py-3 rounded-xl text-xs transition-all flex items-center gap-1.5"
                >
                  <FileJson className="w-4 h-4 text-slate-400" />
                  <span>Экспортировать JSON анкеты</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('anketa');
                    showToast('📝 Переход на страницу редактирования анкеты', 'info');
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-3 rounded-xl text-xs transition-all"
                >
                  Изменить параметры анкеты
                </button>

              </div>

            </div>
          )}

        </div>

      </main>

      {/* FOOTER */}
      <footer className="container max-w-6xl mx-auto px-4 mt-12 text-center text-xs text-slate-400 font-light leading-relaxed print:hidden">
        <p className="border-t border-slate-200 pt-6">
          <strong>Индекс самодостаточности SSI (Self-Sufficiency Index) — TRUSEK-6 + MEI</strong>
        </p>
        <p className="mt-1">
          Методический проект Технопарка Северо-Кавказского федерального университета (СКФУ). © 2025–2026 Все права защищены.
        </p>
      </footer>
    </div>
  );
}

// ========================================================
// UTILITY: TOOLTIP COMPONENT WITH CUSTOM LABELS
// ========================================================
interface TooltipProps {
  text: string;
}

function Tooltip({ text }: TooltipProps) {
  const [visible, setVisible] = useState(false);
  
  return (
    <div className="relative inline-block print:hidden select-none">
      <button
        type="button"
        onMouseEnter={() => setVisible(true)}
        onMouseLeave={() => setVisible(false)}
        onClick={() => setVisible(!visible)}
        className="w-4 h-4 rounded-full bg-slate-150 inline-flex items-center justify-center text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors focus:outline-none"
      >
        <HelpCircle className="w-3.5 h-3.5" />
      </button>

      {visible && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 bg-slate-850 text-white text-[11px] p-3 rounded-lg shadow-xl border border-slate-700 z-30 leading-snug font-normal text-center select-none">
          {text}
          <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-850" />
        </div>
      )}
    </div>
  );
}

// ========================================================
// UTILITY: DETAILED LILY SWEEP FLOWER GEOMETRY RENDERING  
// ========================================================
function MiniLily({ subfactors }: { subfactors: Subfactors }) {
  const cx = 50;
  const cy = 50;
  const maxRadius = 38;
  const factorKeys: (keyof Subfactors)[] = ['T', 'U', 'R', 'S', 'E', 'K'];
  
  const factorColors: Record<keyof Subfactors, string> = {
    T: '#a855f7', // purple
    U: '#3b82f6', // blue
    R: '#ec4899', // pink
    S: '#06b6d4', // cyan
    E: '#f43f5e', // rose
    K: '#10b981'  // emerald
  };

  return (
    <svg viewBox="0 0 100 100" className="w-[84px] h-[84px] md:w-[94px] md:h-[94px] block drop-shadow-2xl select-none">
      <defs>
        {factorKeys.map(key => (
          <linearGradient key={`mini-grad-${key}`} id={`mini-grad-${key}`} x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity={0.15} />
            <stop offset="85%" stopColor={factorColors[key]} stopOpacity={0.88} />
            <stop offset="100%" stopColor={factorColors[key]} stopOpacity={0.98} />
          </linearGradient>
        ))}
      </defs>

      {/* Shaggy Golden Stamens / Тычинки, делающие лилию лохматой */}
      {factorKeys.map((_, index) => {
        const midAngle = index * 60 - 60; // Gaps centered between petals
        const offsets = [-13, 0, 13]; // 3 delicate golden stems in each gap
        
        return offsets.map((offset, oIdx) => {
          const angleRad = ((midAngle + offset) * Math.PI) / 180;
          const stamenLen = 16 + (oIdx % 2 === 0 ? 6 : 9);
          
          const xTip = cx + Math.cos(angleRad) * stamenLen;
          const yTip = cy + Math.sin(angleRad) * stamenLen;
          
          const bendAngleRad = ((midAngle + offset * 0.55) * Math.PI) / 180;
          const xControl = cx + Math.cos(bendAngleRad) * stamenLen * 0.55;
          const yControl = cy + Math.sin(bendAngleRad) * stamenLen * 0.55;
          
          return (
            <g key={`mini-stamen-${index}-${oIdx}`}>
              <path
                d={`M ${cx} ${cy} Q ${xControl} ${yControl} ${xTip} ${yTip}`}
                fill="none"
                stroke="#fbbf24"
                strokeWidth="0.75"
                opacity="0.9"
              />
              <circle
                cx={xTip}
                cy={yTip}
                r="1.2"
                fill="#d97706"
                stroke="#fef08a"
                strokeWidth="0.4"
              />
            </g>
          );
        });
      })}

      {/* Petals */}
      {factorKeys.map((key, index) => {
        const angleDeg = index * 60 - 90;
        const angleRad = (angleDeg * Math.PI) / 180;
        const leftWingRad = (angleDeg - 25) * Math.PI / 180;
        const rightWingRad = (angleDeg + 25) * Math.PI / 180;

        const valueScore = subfactors[key];
        // Mini logarithmic petal projection
        const pRadius = 10 + (maxRadius - 10) * (Math.log2(1 + valueScore) / Math.log2(11));

        const xTip = cx + Math.cos(angleRad) * pRadius;
        const yTip = cy + Math.sin(angleRad) * pRadius;

        const xControlLeft = cx + Math.cos(leftWingRad) * pRadius * 0.75;
        const yControlLeft = cy + Math.sin(leftWingRad) * pRadius * 0.75;

        const xControlRight = cx + Math.cos(rightWingRad) * pRadius * 0.75;
        const yControlRight = cy + Math.sin(rightWingRad) * pRadius * 0.75;

        return (
          <g key={key}>
            <path
              d={`M ${cx} ${cy} C ${xControlLeft} ${yControlLeft}, ${xTip} ${yTip}, ${xTip} ${yTip} C ${xTip} ${yTip}, ${xControlRight} ${yControlRight}, ${cx} ${cy} Z`}
              fill={`url(#mini-grad-${key})`}
              stroke={factorColors[key]}
              strokeWidth="0.9"
              strokeLinecap="round"
            />
            {/* White/light central rib for realistic lily petal feel */}
            <path
              d={`M ${cx + Math.cos(angleRad) * 6} ${cy + Math.sin(angleRad) * 6} Q ${cx + Math.cos(angleRad) * pRadius * 0.55} ${cy + Math.sin(angleRad) * pRadius * 0.55} ${xTip - Math.cos(angleRad) * 1.5} ${yTip - Math.sin(angleRad) * 1.5}`}
              fill="none"
              stroke="#ffffff"
              strokeWidth="0.5"
              opacity="0.65"
            />
          </g>
        );
      })}

      {/* Inner small core representing the SSI index label */}
      <circle cx={cx} cy={cy} r="8.5" fill="#ffffff" stroke="#6366f1" strokeWidth="1.5" />
      <text x={cx} y={cy + 2} textAnchor="middle" fontSize="6.2" fontWeight="950" fill="#4f46e5" className="font-sans">
        SSI
      </text>
    </svg>
  );
}

interface LilyProps {
  subfactors: Subfactors;
  ssi: number;
  data: StartupData;
}

function LilySvg({ subfactors, ssi, data }: LilyProps) {
  const cx = 700;
  const cy = 700;
  const maxRadius = 450; // Doubled petals size (from original ~200-240) for outstanding readability

  // Logarithmic projection maps score [0..10] to the radius [90..450].
  // Gives intuitive vision to which factors are the main drivers to cross the SOM market entry line!
  const getLogarithmicRadius = (score: number) => {
    const minRadius = 90; // Center circle boundary
    const logVal = Math.log2(1 + score) / Math.log2(11);
    return minRadius + (maxRadius - minRadius) * logVal;
  };

  // Ordering of the factors to draw a continuous cyclic loop
  // Order: Time (T), Utility (U), Retention (R), Social (S), Emotion (E), Capital (K)
  const factorKeys: (keyof Subfactors)[] = ['T', 'U', 'R', 'S', 'E', 'K'];
  
  const factorLabels: Record<keyof Subfactors, string> = {
    T: 'T Окупаемость бизнеса',
    U: 'U Острота боли клиента',
    R: 'R LTV и лояльность клиентов',
    S: 'S Органический рост (сарафан)',
    E: 'E Эмоциональный клей продукта',
    K: 'K Капитал-эффективность и маржа'
  };

  const factorColors: Record<keyof Subfactors, string> = {
    T: '#a855f7', // purple
    U: '#6366f1', // indigo
    R: '#f43f5e', // rose
    S: '#14b8a6', // teal
    E: '#f59e0b', // amber
    K: '#10b981'  // emerald
  };

  // Find which of the 6 core factor scores is the highest (the "pulling factor")
  const maxFactorKey = factorKeys.reduce((max, key) => subfactors[key] > subfactors[max] ? key : max, factorKeys[0]);

  // Subfactors list calculator utilizing the norm utility
  const getSubfactorInfo = (key: keyof Subfactors): { key: string; label: string; rawVal: string; score: number }[] => {
    switch (key) {
      case 'T':
        return [
          {
            key: 'T1',
            label: 'До EBITDA+',
            rawVal: `${data.t1} мес`,
            score: norm(data.t1, 1, 36, true),
          },
          {
            key: 'T2',
            label: 'Окупаемость',
            rawVal: `${data.t2} мес`,
            score: norm(data.t2, 1, 60, true),
          },
        ];
      case 'U':
        return [
          {
            key: 'U1',
            label: 'Ущерб отказа',
            rawVal: data.u1 >= 1000 ? `${(data.u1 / 1000).toFixed(0)} тыс.р.` : `${data.u1} руб`,
            score: norm(data.u1, 0, 300000),
          },
          {
            key: 'U2',
            label: 'Потребность',
            rawVal: `${data.u2} раз/г`,
            score: norm(data.u2, 1, 52),
          },
        ];
      case 'R':
        return [
          {
            key: 'R1',
            label: 'Частота покуп',
            rawVal: `${data.r1} р/г`,
            score: norm(data.r1, 0, 52),
          },
          {
            key: 'R2',
            label: 'LTV/CAC',
            rawVal: `${Number(data.r2).toFixed(1)}x`,
            score: norm(data.r2, 0, 10),
          },
        ];
      case 'S':
        return [
          {
            key: 'S1',
            label: 'Рекомендац.',
            rawVal: `${data.s1}%`,
            score: norm(data.s1, 0, 100),
          },
          {
            key: 'S2',
            label: 'Лояльность NPS',
            rawVal: `${data.s2}`,
            score: norm(data.s2, -100, 100),
          },
        ];
      case 'E':
        return [
          {
            key: 'E1',
            label: 'Время сессии',
            rawVal: `${data.e1} мин`,
            score: norm(data.e1, 0, 60),
          },
          {
            key: 'E2',
            label: 'Качество/Цена',
            rawVal: `${Number(data.e2).toFixed(2)}x`,
            score: norm(data.e2, 0, 2),
          },
        ];
      case 'K':
        return [
          {
            key: 'K1',
            label: 'Старт CAPEX',
            rawVal: data.k1 >= 1000 ? `${(data.k1 / 1000).toFixed(1)} млн` : `${data.k1} тыс.р.`,
            score: norm(data.k1, 0, 5000, true),
          },
          {
            key: 'K2',
            label: 'Маржа OPEX',
            rawVal: `${data.k2}%`,
            score: norm(data.k2, 0, 80),
          },
        ];
      default:
        return [];
    }
  };

  return (
    <svg 
      viewBox="0 0 1400 1400" 
      className="w-full h-full select-none"
    >
      <defs>
        {/* Gradients for each beautiful petal */}
        {factorKeys.map(key => (
          <linearGradient key={key} id={`grad-${key}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity={0.25} />
            <stop offset="80%" stopColor={factorColors[key]} stopOpacity={0.8} />
            <stop offset="100%" stopColor={factorColors[key]} stopOpacity={0.95} />
          </linearGradient>
        ))}
        {/* Soft shadow for center circle and cards */}
        <filter id="soft-shadow" x="-30%" y="-30%" width="160%" height="160%">
          <feDropShadow dx="0" dy="5" stdDeviation="6" floodOpacity="0.16" />
        </filter>
        {/* Golden glow for the pulling factor */}
        <filter id="gold-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="0" stdDeviation="10" floodColor="#f59e0b" floodOpacity="0.8" />
        </filter>
        {/* Stamen gradient for shaggy lily stamens */}
        <linearGradient id="stamen-grad" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity={0.2} />
          <stop offset="25%" stopColor="#fde047" />
          <stop offset="75%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#b45309" />
        </linearGradient>
      </defs>

      {/* Decorative Outer Grid and Logarithmic guidelines */}
      <circle cx={cx} cy={cy} r={maxRadius + 30} fill="#f8fafc" stroke="#e2e8f0" strokeWidth="2.5" />
      
      {/* 1. Zone of Dominance (SAM/Scale) - Score >= 8 */}
      <circle cx={cx} cy={cy} r={getLogarithmicRadius(8.0)} fill="none" stroke="#10b981" strokeWidth="1.5" strokeDasharray="5 5" opacity="0.6" />
      <text x={cx} y={cy - getLogarithmicRadius(8.0) - 8} textAnchor="middle" fontSize="11" fontWeight="700" fill="#047857" opacity="0.8" className="font-sans">
        🚀 ЗОНА SAM • МАСШТАБНЫЙ РОСТ (Оценка &ge; 8)
      </text>

      {/* 2. Zone of Life/Survival (SOM/Life) - Score >= 5 */}
      <circle cx={cx} cy={cy} r={getLogarithmicRadius(5.0)} fill="none" stroke="#3b82f6" strokeWidth="2" strokeDasharray="6 4" />
      <text x={cx} y={cy - getLogarithmicRadius(5.0) - 10} textAnchor="middle" fontSize="13" fontWeight="800" fill="#1d4ed8" className="font-sans">
        ⚡ ТОЧКА ВХОДА В SOM • ЖИЗНЬ ИМЕЕТСЯ! (Барьер &ge; 5)
      </text>

      {/* 3. Operational Break-even (TAV/Danger) - Score <= 3 */}
      <circle cx={cx} cy={cy} r={getLogarithmicRadius(3.0)} fill="none" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4 6" opacity="0.8" />
      <text x={cx} y={cy - getLogarithmicRadius(3.0) - 8} textAnchor="middle" fontSize="11" fontWeight="700" fill="#b91c1c" opacity="0.9" className="font-sans">
        ⚠️ ПОРОГ ВЫЖИВАНИЯ TAV • ЗОНА РИСКА (Ниже 3)
      </text>

      {/* MARKET METRICS WIDGETS IN THE CORNERS OF THE IMAGE */}
      
      {/* 1. TAM Widget - Top Left */}
      <g transform="translate(40, 40)" filter="url(#soft-shadow)">
        <rect x="0" y="0" width="190" height="110" rx="16" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
        <rect x="0" y="0" width="190" height="30" rx="16" fill="#f1f5f9" />
        <rect x="0" y="15" width="190" height="15" fill="#f1f5f9" />
        <text x="95" y="20" textAnchor="middle" fontSize="11" fontWeight="800" fill="#475569" className="font-sans tracking-wider uppercase">
          TAM • Весь Рынок
        </text>
        <text x="95" y="65" textAnchor="middle" fontSize="22" fontWeight="900" fill="#0f172a" className="font-mono">
          {data.tam} млн
        </text>
        <text x="95" y="90" textAnchor="middle" fontSize="9" fontWeight="600" fill="#64748b" className="font-sans">
          Общий потенциал в РФ (руб.)
        </text>
      </g>

      {/* 2. SAM Widget - Top Right */}
      <g transform="translate(1170, 40)" filter="url(#soft-shadow)">
        <rect x="0" y="0" width="190" height="110" rx="16" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
        <rect x="0" y="0" width="190" height="30" rx="16" fill="#e0e7ff" />
        <rect x="0" y="15" width="190" height="15" fill="#e0e7ff" />
        <text x="95" y="20" textAnchor="middle" fontSize="11" fontWeight="800" fill="#4338ca" className="font-sans tracking-wider uppercase">
          SAM • Доступный Рынок
        </text>
        <text x="95" y="65" textAnchor="middle" fontSize="22" fontWeight="900" fill="#4338ca" className="font-mono">
          {data.sam} млн
         </text>
        <text x="95" y="90" textAnchor="middle" fontSize="9" fontWeight="600" fill="#6366f1" className="font-sans">
          Региональный целевой сегмент
        </text>
      </g>

      {/* 3. SOM Widget - Bottom Left */}
      <g transform="translate(40, 1250)" filter="url(#soft-shadow)">
        <rect x="0" y="0" width="190" height="110" rx="16" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
        <rect x="0" y="0" width="190" height="30" rx="16" fill="#fef3c7" />
        <rect x="0" y="15" width="190" height="15" fill="#fef3c7" />
        <text x="95" y="20" textAnchor="middle" fontSize="11" fontWeight="800" fill="#b45309" className="font-sans tracking-wider uppercase">
          SOM • Достижимый Рынок
        </text>
        <text x="95" y="65" textAnchor="middle" fontSize="22" fontWeight="900" fill="#b45309" className="font-mono">
          {data.som} млн
        </text>
        <text x="95" y="90" textAnchor="middle" fontSize="9" fontWeight="600" fill="#d97706" className="font-sans">
          Реальная доля продаж за 3 года
        </text>
      </g>

      {/* 4. TAV Widget - Bottom Right (Operational Break-even Threshold comparison) */}
      <g transform="translate(1170, 1250)" filter="url(#soft-shadow)">
        <rect x="0" y="0" width="190" height="110" rx="16" fill="#ffffff" stroke="#fecdd3" strokeWidth="1.5" />
        <rect x="0" y="0" width="190" height="30" rx="16" fill="#ffe4e6" />
        <rect x="0" y="15" width="190" height="15" fill="#ffe4e6" />
        <text x="95" y="20" textAnchor="middle" fontSize="11" fontWeight="800" fill="#be123c" className="font-sans tracking-wider uppercase">
          TAV • Порог Выживания
        </text>
        <text x="95" y="65" textAnchor="middle" fontSize="22" fontWeight="900" fill="#be123c" className="font-mono">
          {data.tav} млн
        </text>
        <text x="95" y="90" textAnchor="middle" fontSize="9" fontWeight="600" fill="#be123c" className="font-sans">
          Запас: {(data.som / (data.tav || 1)).toFixed(1)}x от операцион. OPEX
        </text>
      </g>

      {/* Petals Grid */}
      {factorKeys.map((key, index) => {
        // Angles separated into 6 equal sectors starting from -90 degrees (top vertical point)
        const angleDeg = index * 60 - 90;
        const angleRad = (angleDeg * Math.PI) / 180;
        
        // Value bounded to 0-10 scale mapped into radius fraction
        const valueScore = subfactors[key];
        // Calculate dynamic length of the petal utilizing logarithmic survival formula
        const petalLength = getLogarithmicRadius(valueScore);

        // Peak target coordinate of the outer petal tip
        const xTip = cx + Math.cos(angleRad) * petalLength;
        const yTip = cy + Math.sin(angleRad) * petalLength;

        // Control vectors for drafting realistic curved bezier petals with custom expansion
        const leftWingRad = ((angleDeg - 25) * Math.PI) / 180;
        const rightWingRad = ((angleDeg + 25) * Math.PI) / 180;

        const xControlLeft = cx + Math.cos(leftWingRad) * petalLength * 0.75;
        const yControlLeft = cy + Math.sin(leftWingRad) * petalLength * 0.75;

        const xControlRight = cx + Math.cos(rightWingRad) * petalLength * 0.75;
        const yControlRight = cy + Math.sin(rightWingRad) * petalLength * 0.75;

        // Outer label location coordinates situate on a wide radius circle
        const labelDistance = 560; // Expanded to make massive space for huge doubled petals
        const xLabel = cx + Math.cos(angleRad) * labelDistance;
        const yLabel = cy + Math.sin(angleRad) * labelDistance;

        const [sub1, sub2] = getSubfactorInfo(key);
        const isMaxFactor = key === maxFactorKey;

        return (
          <g key={key} className="transition-all duration-700">
            {/* Curved elegant petal drawn using cubic beziers */}
            <path
              d={`M ${cx} ${cy} C ${xControlLeft} ${yControlLeft}, ${xTip} ${yTip}, ${xTip} ${yTip} C ${xTip} ${yTip}, ${xControlRight} ${yControlRight}, ${cx} ${cy} Z`}
              fill={`url(#grad-${key})`}
              stroke={isMaxFactor ? '#f59e0b' : factorColors[key]}
              strokeWidth={isMaxFactor ? '6' : '4'}
              filter={isMaxFactor ? 'url(#gold-glow)' : undefined}
              strokeLinecap="round"
              className="hover:fill-opacity-95 transition-all duration-300 cursor-pointer"
            >
              <title>{`${factorLabels[key]}: ${valueScore.toFixed(1)} / 10 ${isMaxFactor ? '(Главный вытягивающий драйвер!)' : ''}`}</title>
            </path>

            {/* Delicately detailed central rib and contour veins inside the petal */}
            <path
              d={`M ${cx + Math.cos(angleRad) * 90} ${cy + Math.sin(angleRad) * 90} Q ${cx + Math.cos(angleRad) * petalLength * 0.58} ${cy + Math.sin(angleRad) * petalLength * 0.58} ${xTip - Math.cos(angleRad) * 5} ${yTip - Math.sin(angleRad) * 5}`}
              fill="none"
              stroke="#ffffff"
              strokeWidth="2.5"
              opacity="0.6"
              strokeLinecap="round"
            />
            <path
              d={`M ${cx + Math.cos(angleRad) * 95} ${cy + Math.sin(angleRad) * 95} Q ${cx + Math.cos(angleRad) * petalLength * 0.58} ${cy + Math.sin(angleRad) * petalLength * 0.58} ${xTip - Math.cos(angleRad) * 5} ${yTip - Math.sin(angleRad) * 5}`}
              fill="none"
              stroke={factorColors[key]}
              strokeWidth="1.2"
              opacity="0.4"
              strokeDasharray="4 4"
            />

            {/* Glowing dot representing the tip coordinate of factor strength */}
            <circle 
              cx={xTip} 
              cy={yTip} 
              r={isMaxFactor ? '9' : '6'} 
              fill={isMaxFactor ? '#f59e0b' : factorColors[key]} 
              stroke="#ffffff" 
              strokeWidth="2.5" 
              className="shadow-md" 
            />

            {/* Connecting thin line to give it structural depth */}
            <line
              x1={xTip}
              y1={yTip}
              x2={cx + Math.cos(angleRad) * (labelDistance - 40)}
              y2={cy + Math.sin(angleRad) * (labelDistance - 40)}
              stroke={isMaxFactor ? '#f59e0b' : factorColors[key]}
              strokeWidth={isMaxFactor ? '2' : '1.2'}
              strokeDasharray="2 3"
              opacity="0.75"
            />

            {/* Sub-factor cards with custom positioning */}
            <g transform={`translate(${xLabel}, ${yLabel})`}>
              <rect
                x="-95"
                y="-40"
                width="190"
                height="80"
                rx="14"
                fill="#ffffff"
                stroke={isMaxFactor ? '#f59e0b' : factorColors[key]}
                strokeWidth={isMaxFactor ? '3.5' : '2'}
                filter="url(#soft-shadow)"
              />
              
              {/* If this is the highest score factor, render a prominent gold crown button badge at the top */}
              {isMaxFactor && (
                <g transform="translate(0, -52)">
                  <rect
                    x="-80"
                    y="0"
                    width="160"
                    height="18"
                    rx="6"
                    fill="#f59e0b"
                    stroke="#d97706"
                    strokeWidth="1"
                  />
                  <text
                    textAnchor="middle"
                    y="11"
                    fontSize="9"
                    fontWeight="900"
                    fill="#ffffff"
                    className="font-sans tracking-wider"
                  >
                    🌟 ВЫТЯГИВАЮЩИЙ ДРАЙВЕР
                  </text>
                </g>
              )}

              <text
                textAnchor="middle"
                fontSize="13"
                fontWeight="900"
                fill={isMaxFactor ? '#d97706' : factorColors[key]}
                y="-21"
                className="font-sans"
              >
                {key} • {valueScore.toFixed(1)} / 10
              </text>
              
              <text
                textAnchor="middle"
                fontSize="9"
                fill="#475569"
                fontWeight="800"
                y="-9"
                className="font-sans uppercase tracking-wider"
              >
                {factorLabels[key].substring(2)}
              </text>

              <line x1="-80" y1="-2" x2="80" y2="-2" stroke="#e2e8f0" strokeWidth="1" />

              <text
                textAnchor="middle"
                fontSize="9"
                fill="#1e293b"
                fontWeight="500"
                y="13"
                className="font-sans"
              >
                <tspan fontWeight="800" fill={factorColors[key]}>{sub1.key}:</tspan> {sub1.label} → <tspan fontWeight="700" fill="#030712">{sub1.rawVal}</tspan> <tspan fontWeight="850" fill={factorColors[key]}>[{sub1.score.toFixed(1)}]</tspan>
              </text>

              <text
                textAnchor="middle"
                fontSize="9"
                fill="#1e293b"
                fontWeight="500"
                y="27"
                className="font-sans"
              >
                <tspan fontWeight="800" fill={factorColors[key]}>{sub2.key}:</tspan> {sub2.label} → <tspan fontWeight="700" fill="#030712">{sub2.rawVal}</tspan> <tspan fontWeight="850" fill={factorColors[key]}>[{sub2.score.toFixed(1)}]</tspan>
              </text>
            </g>
          </g>
        );
      })}

      {/* 30 Glorious and Shaggy Golden Stamens / 30 золотых раскидистых тычинок как на рисунке */}
      {factorKeys.map((_, index) => {
        const midAngle = index * 60 - 60; // Gaps centered between the 6 petals
        const offsets = [-16, -8, 0, 8, 16]; // 5 rich staggered filaments per gap
        
        return offsets.map((offset, oIdx) => {
          const angleDeg = midAngle + offset;
          const angleRad = (angleDeg * Math.PI) / 180;
          
          // Organic staggering lengths so it looks beautifully shaggy (лохматая лилия!)
          const stamenLen = 170 + (oIdx % 2 === 0 ? 55 : 85) + Math.sin(oIdx * 1.5) * 15; 
          
          const xTip = cx + Math.cos(angleRad) * stamenLen;
          const yTip = cy + Math.sin(angleRad) * stamenLen;
          
          // Slight natural curving bend
          const bendAngleRad = (angleDeg - offset * 0.45) * Math.PI / 180;
          const xControl = cx + Math.cos(bendAngleRad) * stamenLen * 0.55;
          const yControl = cy + Math.sin(bendAngleRad) * stamenLen * 0.55;
          
          return (
            <g key={`stamen-${index}-${oIdx}`}>
              {/* Filament Shadow */}
              <path
                d={`M ${cx} ${cy} Q ${xControl} ${yControl} ${xTip} ${yTip}`}
                fill="none"
                stroke="#78350f"
                strokeWidth="3.2"
                opacity="0.12"
              />
              {/* Filament core thread */}
              <path
                d={`M ${cx} ${cy} Q ${xControl} ${yControl} ${xTip} ${yTip}`}
                fill="none"
                stroke="url(#stamen-grad)"
                strokeWidth="2"
                strokeLinecap="round"
              />
              {/* Double-lobe natural Lily Anther / Круглые пыльники с легким раздвоением */}
              <g transform={`translate(${xTip}, ${yTip}) rotate(${angleDeg + 90})`}>
                <ellipse cx="-1.8" cy="0" rx="3" ry="5.5" fill="#d97706" stroke="#fbbf24" strokeWidth="0.6" />
                <ellipse cx="1.8" cy="0" rx="3" ry="5.5" fill="#be123c" stroke="#fef08a" strokeWidth="0.6" />
                <circle cx="-1.2" cy="-1.5" r="0.8" fill="#ffffff" opacity="0.7" />
              </g>
            </g>
          );
        });
      })}

      {/* Polished Core Centre circle showing aggregate results */}
      <g filter="url(#soft-shadow)" className="cursor-pointer">
        <circle 
          cx={cx} 
          cy={cy} 
          r="90" 
          fill="#ffffff" 
          stroke="#6366f1" 
          strokeWidth="6" 
        />
        
        <text 
          x={cx} 
          y={cy - 16} 
          textAnchor="middle" 
          fontSize="20" 
          fontWeight="850" 
          fill="#6366f1"
          className="font-display tracking-widest"
        >
          SSI
        </text>

        <text 
          x={cx} 
          y={cy + 34} 
          textAnchor="middle" 
          fontSize="48" 
          fontWeight="900" 
          fill="#0f172a"
          className="font-mono tracking-tighter"
        >
          {ssi.toFixed(1)}
        </text>
      </g>
    </svg>
  );
}
