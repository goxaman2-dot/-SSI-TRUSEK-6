import { StartupData, Subfactors, CalculationResult, FactorInterpretation } from './types';

export const INITIAL_STARTUP_DATA: StartupData = {
  name: 'ИДЕИДВОРА.РФ',
  author: 'Скуратова Надежда Борисовна',
  u1: 180000,  // Разница стоимости ручного проектирования в архбюро (200 т.р.) и онлайн (20 т.р.) = 180 000 руб
  u2: 12,      // 12 эпизодов потребности в год у управляющей компании или товарищества ТСЖ
  e1: 45,      // 45 минут взаимодействия за сессию в умном онлайн-конструкторе
  e2: 0.17,    // Отношение нашей цены (25 т.р.) к конкурентам (150 т.р.) = 0.17
  r1: 4,       // 4 повторных заказа проектов благоустройства дворов в год от одной крупной УК
  r2: 6.5,     // LTV / CAC = 6.5 за счет автоматизированной воронки
  k1: 1000,    // CAPEX на разработку MVP стартапа согласно смете планируемых работ = 1 000 тыс. руб
  k2: 70,      // Высокая маржинальность автоматических чертежей цифровой платформы = 70%
  t1: 12,      // 12 месяцев до прибыльности EBITDA+ с момента разработки и пилотного пуска
  t2: 37,      // Полная окупаемость первоначальных затрат проекта = 37 месяцев
  s1: 35,      // 35% клиентов приходят по рекомендациям через профессиональные СРО и ТСЖ
  s2: 65,      // NPS = 65 (очень высокий уровень удовлетворенности за счет простоты и легитимности)
  tam: 17500,  // TAM (весь доступный рынок РФ проектирования дворов) = 17 500 млн руб
  sam: 32.5,   // SAM (целевой региональный рынок Ставропольского края и КЧР) = 32.5 млн руб
  som: 15.0,   // SOM (реалистичный плановый захват за 3 года) = 15.0 млн руб
  tav: 4.5,    // TAV (порог автономии - необходимый минимум выручки для самоокупаемости) = 4.5 млн руб
};

export const EMPTY_STARTUP_DATA: StartupData = {
  name: '',
  author: '',
  u1: 0,
  u2: 1,
  e1: 0,
  e2: 1,
  r1: 0,
  r2: 1,
  k1: 0,
  k2: 0,
  t1: 1,
  t2: 1,
  s1: 0,
  s2: 0,
  tam: 0,
  sam: 0,
  som: 0,
  tav: 0,
};

export function norm(val: number, min: number, max: number, invert: boolean = false): number {
  if (isNaN(val) || val === null || val === undefined) return 0;
  let v = ((val - min) / (max - min)) * 10;
  if (invert) v = 10 - v;
  return Math.max(0, Math.min(10, v));
}

export function calculateSubfactors(v: StartupData): Subfactors {
  return {
    U: Math.min(10, Math.max(0, norm(v.u1, 0, 300000) * 0.5 + norm(v.u2, 1, 52) * 0.5)),
    E: Math.min(10, Math.max(0, norm(v.e1, 0, 60) * 0.5 + norm(v.e2, 0, 2) * 0.5)),
    R: Math.min(10, Math.max(0, norm(v.r1, 0, 52) * 0.5 + norm(v.r2, 0, 10) * 0.5)),
    K: Math.min(10, Math.max(0, norm(v.k1, 0, 5000, true) * 0.5 + norm(v.k2, 0, 80) * 0.5)),
    T: Math.min(10, Math.max(0, norm(v.t1, 1, 36, true) * 0.5 + norm(v.t2, 1, 60, true) * 0.5)),
    S: Math.min(10, Math.max(0, norm(v.s1, 0, 100) * 0.5 + norm(v.s2, -100, 100) * 0.5)),
  };
}

export function calculateResult(data: StartupData): CalculationResult {
  const sub = calculateSubfactors(data);
  const rawSsi = 0.15 * sub.U + 0.20 * sub.E + 0.15 * sub.R + 0.15 * sub.K + 0.20 * sub.T + 0.15 * sub.S;

  let mei = 1.0;
  const { tam, sam, som, tav } = data;
  if (tam > 0 && tav > 0) {
    const share = som / tav;
    const access = sam / tam;
    // MEI weights relative SOM/TAV contribution (60%) and SAM/TAM visibility (40%)
    mei = Math.max(0.3, Math.min(1.5, share * 0.6 + access * 0.4));
  }

  const finalSsi = Math.min(10, rawSsi * mei);

  let interpretation = '';
  let color = '#e74c3c'; // red

  if (finalSsi >= 8.5) {
    interpretation = '🌺 ЛИЛИЯ РАСЦВЕЛА — Мощный самодвижок. Все системы работают эффективно. Прекрасный кандидат на быстрое инвестирование.';
    color = '#10b981'; // green
  } else if (finalSsi >= 7.5) {
    interpretation = '🌿 РАСКРЫВАЕТСЯ — Модель самодостаточна, но есть 1–2 слабых места, сдерживающих рост. Финансирование рекомендуется при плотном мониторинге.';
    color = '#3b82f6'; // blue
  } else if (finalSsi >= 6.5) {
    interpretation = '🌱 ЧАСТИЧНО — Хороший базовый потенциал, но показатели раскрываются очень неравномерно. Требуется целевая точечная доработка.';
    color = '#f59e0b'; // yellow-amber
  } else if (finalSsi >= 5.0) {
    interpretation = '🥀 БУТОН СЛАБЫЙ — Продукт имеет частичную ценность, однако бизнес крайне уязвим. Финансирование условное с жестким планом выравнивания слабых сторон.';
    color = '#d97706'; // dark amber
  } else if (finalSsi >= 3.5) {
    interpretation = '🌑 НЕ РАСКРЫЛАСЬ — Выявлены глубокие системные слабости. Требуется полный перебор бизнес-модели, Pivot или полевой Customer Discovery.';
    color = '#ec4899'; // pinkish red
  } else {
    interpretation = '💀 КРИТИЧЕСКИ — Внутренний самоокупаемый двигатель полностью отсутствует. Вернитесь к проектированию бизнес-логики с самого начала.';
    color = '#ef4444'; // deep red
  }

  return {
    subfactors: sub,
    rawSsi,
    mei,
    finalSsi,
    interpretation,
    color,
  };
}

export function getFactorInterpretations(sub: Subfactors): FactorInterpretation[] {
  const factors: { key: keyof Subfactors; name: string; weight: number; desc: string; weak: string; medium: string }[] = [
    {
      key: 'U',
      name: 'Ценность и боль клиента (U)',
      weight: 0.15,
      desc: 'Острота проблемы покупателя: готовность платить любые деньги и ущерб от отказа',
      weak: 'Клиент почти не чувствует острой боли без вашего продукта, ему легко отказаться. Найдите узкую нишу или сегмент, для которого ваше решение критически важно — будьте «таблеткой от боли», а не «витаминкой».',
      medium: 'Умеренная ценность. Продукт аккуратно решает задачу, но клиент может без труда переключиться на аналоги. Повышайте глубину интеграции в процессы клиента, создавая высокие транзакционные барьеры для его ухода.',
    },
    {
      key: 'E',
      name: 'Эмоциональный клей (E)',
      weight: 0.20,
      desc: 'Вау-эффект продукта: харизматичность бренда, вовлеченность и готовность платить премию к цене',
      weak: 'Продукт безликий и не вызывает сильного отклика. Добавьте харизмы: улучшите дизайн, внедрите геймификацию, личную историю фаундеров или обеспечьте вау-эффект прямо в первые 5 минут использования.',
      medium: 'Хороший эмоциональный фон. Превращайте лояльных покупателей в настоящих амбассадоров вашего бренда, делитесь внутренней кухней бизнеса и создавайте закрытый клуб лояльных клиентов.',
    },
    {
      key: 'R',
      name: 'Повторные продажи и LTV (R)',
      weight: 0.15,
      desc: 'Регулярность спроса: частота цикличных покупок и прочность удержания кошелька клиента (LTV/CAC)',
      weak: 'Одноразовые продажи — тяжелый бизнес, вынуждающий вечно переплачивать за рекламу. Перестройте структуру оффера: введите подписочные планы, абонентское обслуживание, расходники или регулярный кросс-сейл.',
      medium: 'Покупатели возвращаются, но цикл нестабилен. Внедрите триггерные сценарии в CRM, программы автоматического продления (ребиллинг) и бесшовные скидки на подписочную модель.',
    },
    {
      key: 'K',
      name: 'Капитал-эффективность (K)',
      weight: 0.15,
      desc: 'Дешевизна входа (низкий стартовый CAPEX) и чистая маржинальность операционной модели (OPEX)',
      weak: 'Слишком тяжелая или капиталоемкая бизнес-модель. Сокращайте CAPEX: используйте аутсорс, аренду вместо выкупа, облачные SaaS-системы и контрактное производство для максимального облегчения баланса.',
      medium: 'Бизнес имеет умеренную маржинальность. Регулярно оптимизируйте постоянные затраты, договаривайтесь с поставщиками напрямую и снижайте юнит-косты по мере увеличения масштабов сбыта.',
    },
    {
      key: 'T',
      name: 'Скорость окупаемости (T)',
      weight: 0.20,
      desc: 'Срок запуска MVP, время достижения точки безубыточности EBITDA+ и окупаемости инвестиций',
      weak: 'Затянутый запуск съедает ресурсы («смерть от долгого релиза»). Сокращайте функционал до жесткого ядра MVP: выходите на рынок за 2-4 недели, собирайте реальную обратную связь и докручивайте за счет клиентских денег.',
      medium: 'Штатные сроки окупаемости. Применяйте тактику предпродаж (Pre-sales) и собирайте предоплаты/авансы для финансирования оборотного капитала еще до полноценного развертывания.',
    },
    {
      key: 'S',
      name: 'Сарафанное радио и органика (S)',
      weight: 0.15,
      desc: 'Виральность бизнеса: готовность рекомендовать продукт (NPS) и доля бесплатного трафика',
      weak: 'Бизнес работает в «полной тишине». Запустите регулярный замер NPS, боритесь за устранение негатива и мотивируйте отзывы — дарите бонусы или весомые скидки за честное видео или пост в соцсетях.',
      medium: 'Умеренный сарафан. Внедрите прозрачную реферальную механику «Приведи друга и оба получите бонусы на внутренний счет» для ускорения бесплатного притока клиентов.',
    },
  ];

  return factors.map(f => {
    const score = sub[f.key];
    let status: 'strong' | 'medium' | 'weak' = 'weak';
    let statusLabel = 'Слабо';
    let advice = f.weak;

    if (score >= 7.0) {
      status = 'strong';
      statusLabel = 'Сильно';
      advice = 'Отличный уровень! Фактор выступает локомотивом вашего бизнеса. Масштабируйте его и защищайте от копирования конкурентами.';
    } else if (score >= 5.0) {
      status = 'medium';
      statusLabel = 'Средне';
      advice = f.medium;
    }

    return {
      key: f.key,
      name: f.name,
      weight: f.weight,
      score,
      status,
      statusLabel,
      desc: f.desc,
      advice,
    };
  });
}

export function looksLikeSSIJson(text: string): boolean {
  if (!text || typeof text !== 'string') return false;
  const trimmed = text.trim();
  if (!trimmed.startsWith('{') || !trimmed.endsWith('}')) return false;
  const lower = trimmed.toLowerCase();
  const keys = ['"u1"', '"u2"', '"name"', '"author"', '"e1"', '"k1"', '"t1"'];
  return keys.filter(k => lower.includes(k)).length >= 2;
}

export function parseSSIJson(text: string): Partial<StartupData> | null {
  try {
    const parsed = JSON.parse(text);
    const data: Partial<StartupData> = {};
    const stringKeys: (keyof StartupData)[] = ['name', 'author'];
    const numKeys: (keyof StartupData)[] = [
      'u1', 'u2', 'e1', 'e2', 'r1', 'r2', 'k1', 'k2', 't1', 't2', 's1', 's2', 'tam', 'sam', 'som', 'tav'
    ];

    stringKeys.forEach(k => {
      if (parsed[k] !== undefined) {
        (data as any)[k] = String(parsed[k]);
      }
    });

    numKeys.forEach(k => {
      if (parsed[k] !== undefined) {
        const val = parseFloat(parsed[k]);
        (data as any)[k] = isNaN(val) ? 0 : val;
      }
    });

    return data;
  } catch (e) {
    return null;
  }
}
